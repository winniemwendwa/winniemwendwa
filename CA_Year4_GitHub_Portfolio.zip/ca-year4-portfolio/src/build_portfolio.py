"""Generate visual deliverables from the included public aggregate tables."""
from pathlib import Path
import json
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import numpy as np
from openpyxl import Workbook
from openpyxl.styles import Font,PatternFill,Alignment
from openpyxl.chart import BarChart,Reference
from reportlab.platypus import SimpleDocTemplate,Paragraph,Spacer,Table,TableStyle,Image,PageBreak
from reportlab.lib.styles import getSampleStyleSheet,ParagraphStyle
from reportlab.lib import colors
from reportlab.lib.enums import TA_LEFT
from docx import Document
from docx.shared import Inches,Pt
ROOT=Path(__file__).resolve().parents[1];D=ROOT/'data';F=ROOT/'figures';R=ROOT/'reports'
F.mkdir(exist_ok=True);R.mkdir(exist_ok=True)
GREEN='#17664D';GOLD='#D6A347';INK='#16352D'
plt.rcParams.update({'font.family':'DejaVu Sans','axes.spines.top':False,'axes.spines.right':False,'axes.spines.left':False,'axes.labelcolor':INK,'text.color':INK,'xtick.color':INK,'ytick.color':INK,'figure.facecolor':'white','font.size':11})
y=pd.read_csv(D/'crop_yields.csv');p=pd.read_csv(D/'practices.csv');m=pd.read_csv(D/'indicators.csv');meta=json.loads((D/'provenance.json').read_text())
def chart_yields():
 fig,ax=plt.subplots(figsize=(10,4.2));crops=y.crop.drop_duplicates().tolist();pos=np.arange(len(crops))
 for system,offset,color in [('CA',-.18,GREEN),('CF',.18,GOLD)]:
  t=y[y.system.eq(system)].set_index('crop').loc[crops];bars=ax.bar(pos+offset,t.mean_kg_per_acre,.34,label=system,color=color)
  for b,(_,r) in zip(bars,t.iterrows()):ax.text(b.get_x()+b.get_width()/2,b.get_height()+12,f'{r.mean_kg_per_acre:.0f}\nn={int(r.valid_records)}',ha='center',fontsize=9)
 ax.set_xticks(pos,crops);ax.set_ylim(0,900);ax.set_ylabel('Mean kg per acre');ax.legend(frameon=False);ax.set_title('Crop yields | descriptive CA and CF comparisons',loc='left',fontweight='bold',pad=16);ax.yaxis.grid(alpha=.13);ax.set_axisbelow(True)
 fig.tight_layout();fig.savefig(F/'Crop_yields.png',dpi=180);plt.close(fig)
def chart_practices():
 fig,ax=plt.subplots(figsize=(9,3.8));bars=ax.barh(p.practice,p.percent,color=GREEN);ax.invert_yaxis();ax.set_xlim(0,112);ax.set_xlabel('Percent of valid responses among CA-principles respondents')
 for b,(_,r) in zip(bars,p.iterrows()):ax.text(b.get_width()+1,b.get_y()+b.get_height()/2,f'{r.percent:.1f}% ({int(r.yes_records)}/{int(r.valid_responses)})',va='center',fontsize=10)
 ax.set_title('Practices reported by CA-principles respondents',loc='left',fontweight='bold');fig.tight_layout();fig.savefig(F/'CA_practices.png',dpi=180);plt.close(fig)
chart_yields();chart_practices()
fig=plt.figure(figsize=(12,7),facecolor='#F3F6F1');fig.text(.06,.9,'CONSERVATION AGRICULTURE',fontsize=26,fontweight='bold',color=GREEN);fig.text(.06,.85,'Year 4 survey analysis | Portfolio prepared for Winnie K.',fontsize=15)
for x,value,label in [(.06,'219','Survey records'),(.30,'95.0%','Reported CA practice'),(.57,'73.1%','All three principles / full sample'),(.82,'10.37','Adequate-food months*')]:fig.text(x,.72,value,fontsize=30,fontweight='bold',color=GREEN);fig.text(x,.67,label,fontsize=10)
ax=fig.add_axes([.045,.14,.92,.45]);ax.imshow(plt.imread(F/'Crop_yields.png'));ax.axis('off');fig.text(.06,.07,'*Recorded totals; recall-period wording requires review. CA-CF differences do not establish project impact.',fontsize=10);fig.savefig(F/'Preview.png',dpi=180,bbox_inches='tight');plt.close(fig)
# Excel: aggregate source sheets, formula-linked dashboard, editable charts.
wb=Workbook();dash=wb.active;dash.title='Dashboard'
for path in sorted(D.glob('*.csv')):
 df=pd.read_csv(path);name={'indicators':'Indicators','crop_yields':'Crop Yields','quality_checks':'Quality Checks','practices':'Practices','respondent_gender':'Respondent Gender','household_type':'Household Type','ward':'Ward'}[path.stem];ws=wb.create_sheet(name);ws.append(df.columns.tolist())
 for row in df.itertuples(index=False,name=None):ws.append([None if pd.isna(v) else v for v in row])
 ws.freeze_panes='A2';ws.auto_filter.ref=ws.dimensions
 for c in ws[1]:c.fill=PatternFill('solid',fgColor='17664D');c.font=Font(color='FFFFFF',bold=True)
 for col in ws.columns:
  ws.column_dimensions[col[0].column_letter].width=min(65,max(18,max(len(str(c.value or '')) for c in col[:15])+2))
 for row in ws.iter_rows(min_row=2):
  for c in row:
   if isinstance(c.value,float):c.number_format='0.00'
dash.append(['CONSERVATION AGRICULTURE | YEAR 4']);dash.append(['Portfolio prepared for Winnie K.']);dash.append(['Survey records',meta['records']]);dash.append(['Survey dates',f"{meta['survey_start']} to {meta['survey_end']}"])
dash.append(['Metric','Value','Unit','Numerator','Denominator'])
for i in range(2,len(m)+2):dash.append([f"=Indicators!A{i}",f"=Indicators!D{i}",f"=Indicators!E{i}",f"=Indicators!B{i}",f"=Indicators!C{i}"])
for row in dash.iter_rows(min_row=6,max_row=5+len(m)):row[1].number_format='0.00'
dash.append(['Note','Food provision is provisional; recall labels require review.']);dash.append(['Note','CA-CF comparisons are descriptive, with unequal groups.']);dash.append(['Note','Full-sample all-three-principles rate is 160/219; valid-answer rate is 160/209.']);dash.column_dimensions['A'].width=55;dash.column_dimensions['B'].width=64
for c in dash[5]:c.fill=PatternFill('solid',fgColor='17664D');c.font=Font(color='FFFFFF',bold=True)
# A chart-ready table for both systems, with formulas referring to the aggregate yield sheet.
start=22;dash.cell(start,1,'Crop');dash.cell(start,2,'CA mean kg/acre');dash.cell(start,3,'CF mean kg/acre')
mean_col=list(y.columns).index('mean_kg_per_acre')+1
from openpyxl.utils import get_column_letter
for j,crop in enumerate(y.crop.drop_duplicates(),start+1):
 dash.cell(j,1,crop)
 for col,system in [(2,'CA'),(3,'CF')]:
  source_row=y.index[(y.crop==crop)&(y.system==system)][0]+2;dash.cell(j,col,f"='Crop Yields'!{get_column_letter(mean_col)}{source_row}")
chart=BarChart();chart.title='Mean crop yields (kg/acre)';chart.y_axis.title='kg/acre';chart.add_data(Reference(dash,min_col=2,max_col=3,min_row=start,max_row=start+5),titles_from_data=True);chart.set_categories(Reference(dash,min_col=1,min_row=start+1,max_row=start+5));chart.width=23;chart.height=12;dash.add_chart(chart,'A30')
notes=wb.create_sheet('Methods');notes.append(['Calculation and interpretation notes'])
for line in (ROOT/'METHODS.md').read_text().splitlines():
 if line:notes.append([line])
notes.column_dimensions['A'].width=120
for row in notes:
 row[0].alignment=Alignment(wrap_text=True,vertical='top');notes.row_dimensions[row[0].row].height=max(20,len(str(row[0].value))/1.6)
wb.save(R/'Results.xlsx')
# PDF visual case study.
styles=getSampleStyleSheet();styles.add(ParagraphStyle(name='TitleGreen',fontSize=25,leading=29,textColor=colors.HexColor(GREEN),spaceAfter=14));styles['BodyText'].fontSize=10;styles['BodyText'].leading=15;styles['Heading2'].textColor=colors.HexColor(GREEN)
story=[]
def para(text,style='BodyText'):story.append(Paragraph(text,styles[style]));story.append(Spacer(1,9))
def table(data,widths):
 t=Table(data,colWidths=widths,repeatRows=1);t.setStyle(TableStyle([('BACKGROUND',(0,0),(-1,0),colors.HexColor(GREEN)),('TEXTCOLOR',(0,0),(-1,0),colors.white),('FONTNAME',(0,0),(-1,0),'Helvetica-Bold'),('FONTSIZE',(0,0),(-1,-1),9),('BOTTOMPADDING',(0,0),(-1,-1),9),('TOPPADDING',(0,0),(-1,-1),9),('ROWBACKGROUNDS',(0,1),(-1,-1),[colors.HexColor('#F1F5F0'),colors.white]),('VALIGN',(0,0),(-1,-1),'TOP')]));story.append(t);story.append(Spacer(1,14))
para('Conservation Agriculture<br/>Year 4 Survey Analysis','TitleGreen');para('PORTFOLIO PREPARED FOR WINNIE K. | DATA ANALYSIS &amp; M&E REPORTING');para(f"Source: supplied Year 4 survey export. {meta['records']} records across five wards.<br/>Survey dates: {meta['survey_start']} to {meta['survey_end']}.")
para('The reporting challenge','Heading2');para('Turn a wide household survey export into readable monitoring results while making denominators, zero values, and data-quality concerns visible. This case study provides an Excel dashboard, reproducible aggregate tables, and a documented analysis workflow.')
table([['Measure','Recorded result'],['Survey records','219'],['Reported CA practice','208 / 219 (95.0%)'],['All three principles, full sample','160 / 219 (73.1%)'],['Mean adequate-food months*','10.37 / 12'],['Recorded full-year food adequacy*','129 / 219 (58.9%)']],[330,165]);para('*Food indicators use stored month totals. Mixed recall-period wording and inconsistent month-year labels require review. Survey records are not independently verified unique households.')
para('What this sample demonstrates','Heading2');para('Survey data validation; explicit denominator selection; yield calculations; Excel dashboard design; chart production; and clear reporting of findings and limitations. Tools used to prepare this portfolio: Python, pandas, openpyxl, and matplotlib. The workbook can be reviewed in Excel. No original data-collection or causal-impact claim is made.');story.append(PageBreak())
para('Practices and production','TitleGreen');story.append(Image(str(F/'CA_practices.png'),width=490,height=207));para('Practice rates use valid binary responses among respondents reporting CA principles. They do not use the full sample denominator.');story.append(Image(str(F/'Crop_yields.png'),width=490,height=206));para('Yield = kg harvested / positive acres, averaged over eligible records. Primary means retain genuine zero harvest. CA and CF records may overlap within households, and sample sizes differ. Higher observed CA means cannot establish project impact.');para('Four large CF area entries are retained and flagged. Use the sensitivity results in the workbook to see how screening affects the mean; confirm entries with the source before formal reporting.');story.append(PageBreak())
para('Quality, methods and client value','TitleGreen');para('Validation findings','Heading2');para('No duplicate submission UUIDs were found. All 219 food-month totals were valid integers between 0 and 12, and their stored adequate-food totals agreed with 12 minus inadequate months. Nine records differed between the CA-practice and CA-principles questions. Four conventional-farming area entries exceeded the illustrative 20-acre review threshold.')
para('How the analysis was built','Heading2');para('1. Map survey fields and retain the private source unchanged.<br/>2. Convert numeric fields and standardise yes/no responses.<br/>3. Apply growth, harvested-status, area, and harvest eligibility rules.<br/>4. Produce counts, rates, mean and median yields, and sensitivity tables.<br/>5. Export aggregate CSV tables, charts, an Excel dashboard, and this case study.')
para('Limits of interpretation','Heading2');para('This single export has no baseline or target table. Findings are descriptive, unweighted, and based on reported values. Missing values are not automatically zero. The positive-harvest-only mean is an alternative view, not the main productivity indicator. Food-recall wording must be confirmed. Extreme CF areas remain unresolved; no values were silently corrected.')
para('Deliverables a client can inspect','Heading2');para('Editable Excel results workbook; documented indicator denominators; yield summary and data-quality tables; clear PNG charts; aggregate CSV exports; and scripts for reproduction. The GitHub package includes methods and an Upwork entry draft.')
para('Public sample and attribution','Heading2');para('Names, GPS, submission identifiers, exact timestamps, and household-level data are excluded. This portfolio was prepared with AI assistance from the supplied dataset. Confirm your role and permission to disclose project results before publishing. This package does not grant rights over the underlying organisation’s data.')
def footer(canvas,doc):
 canvas.setFont('Helvetica',8);canvas.setFillColor(colors.HexColor(GREEN));canvas.drawString(44,28,'WINNIE K. | CONSERVATION AGRICULTURE ANALYSIS PORTFOLIO');canvas.drawRightString(550,28,str(doc.page))
SimpleDocTemplate(str(R/'Portfolio.pdf'),pagesize=(595,842),rightMargin=44,leftMargin=44,topMargin=40,bottomMargin=48).build(story,onFirstPage=footer,onLaterPages=footer)
# Editable companion follows the same evidence and methods.
doc=Document();doc.add_heading('Conservation Agriculture — Year 4 Survey Analysis',0);doc.add_paragraph('Portfolio prepared for Winnie K. | Data Analysis & M&E Reporting')
doc.add_paragraph('Source: CA YR4 RESULTS.xlsx; 219 survey records across five wards. This portfolio was rebuilt from the supplied export with AI assistance.')
doc.add_heading('Selected findings',1)
for _,r in m.iterrows():doc.add_paragraph(f"{r.indicator}: {r.value:.2f} {r.unit}; denominator = {int(r.denominator)}.")
doc.add_picture(str(F/'CA_practices.png'),width=Inches(6));doc.add_picture(str(F/'Crop_yields.png'),width=Inches(6))
for line in (ROOT/'METHODS.md').read_text().splitlines():
 if line.startswith('# '):doc.add_heading(line[2:],1)
 elif line.startswith('## '):doc.add_heading(line[3:],2)
 elif line:doc.add_paragraph(line)
doc.add_page_break();doc.add_heading('Upwork portfolio wording',1)
for line in (ROOT/'UPWORK_COPY.md').read_text().splitlines():
 if line:doc.add_paragraph(line.replace('**','').lstrip('# '))
doc.styles['Normal'].font.name='Calibri';doc.styles['Normal'].font.size=Pt(11);doc.save(R/'Portfolio.docx')
print('Created charts, preview, Excel workbook, PDF and Word case study.')
