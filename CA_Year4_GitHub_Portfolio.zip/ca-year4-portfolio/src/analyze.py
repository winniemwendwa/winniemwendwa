"""Rebuild aggregate portfolio tables from the private, original Year 4 export.
Usage: python src/analyze.py /path/to/CA_YR4_RESULTS.xlsx
Never commit the source workbook or household-level records.
"""
import sys, json
from pathlib import Path
import numpy as np
import pandas as pd
ROOT=Path(__file__).resolve().parents[1]
CROPS={'Maize':(19,20,21,22,23,24),'Cowpeas':(27,None,28,29,30,31),'Green grams':(36,None,37,38,39,40),'Sorghum':(45,46,47,48,49,50),'Millet':(53,54,55,56,57,58)}
def main(source):
    df=pd.read_excel(source).dropna(how='all')
    if len(df.columns)!=350: raise ValueError('Expected the supplied 350-column Year 4 schema. Review field mapping before using another export.')
    norm=lambda s:s.astype('string').str.strip().str.lower()
    num=lambda i:pd.to_numeric(df.iloc[:,i],errors='coerce')
    yes=lambda i:norm(df.iloc[:,i]).eq('yes').fillna(False)
    rows=[]
    def metric(label,n,d,unit='percent'):
        rows.append({'indicator':label,'numerator':float(n),'denominator':int(d),'value':float(n/d*100) if unit=='percent' and d else float(n/d) if d else None,'unit':unit})
    for label,i in [('CA practice reported',18),('CA principles reported',179),('All three CA principles reported',189),('Agroforestry reported',259),('Agricultural advice received',207),('Savings group participation',285)]:
        valid=norm(df.iloc[:,i]).isin(['yes','no']);metric(label,yes(i).sum(),valid.sum())
    inadequate=num(177);valid=inadequate.between(0,12)&(inadequate%1==0)
    adequate=12-inadequate[valid]
    metric('All three principles: full sample',yes(189).sum(),len(df))
    metric('Mean months of adequate food provision',adequate.sum(),len(adequate),'months')
    metric('12 months of adequate food provision',adequate.eq(12).sum(),len(adequate))
    metrics=pd.DataFrame(rows);metrics.to_csv(ROOT/'data/indicators.csv',index=False)
    yields=[];qa=[]
    for crop,(grow,harvest,ca_a,ca_k,cf_a,cf_k) in CROPS.items():
        eligible=yes(grow)
        if harvest is not None: eligible &= yes(harvest)
        for system,ai,ki in [('CA',ca_a,ca_k),('CF',cf_a,cf_k)]:
            area,kg=num(ai),num(ki)
            valid=eligible&area.gt(0)&kg.ge(0)&area.notna()&kg.notna()&np.isfinite(area)&np.isfinite(kg)
            y=kg[valid]/area[valid];positive=y[y.gt(0)]
            screen=valid&area.le(20); screened=kg[screen]/area[screen]
            qa.append({'check':f'{crop} {system}: area over 20 acres (review flag, retained)','count':int((valid&area.gt(20)).sum())})
            yields.append({'crop':crop,'system':system,'valid_records':len(y),'area_over_20_records':int((valid&area.gt(20)).sum()),'screened_mean_kg_per_acre':screened.mean(),'zero_harvest_records':int(y.eq(0).sum()),'mean_kg_per_acre':y.mean(),'median_kg_per_acre':y.median(),'positive_harvest_mean_kg_per_acre':positive.mean(),'positive_harvest_records':len(positive),'area_weighted_kg_per_acre':kg[valid].sum()/area[valid].sum() if valid.any() else np.nan})
            qa.append({'check':f'{crop} {system}: positive harvest with zero or missing area','count':int((yes(grow)&kg.gt(0)&(~area.gt(0))).sum())})
    pd.DataFrame(yields).to_csv(ROOT/'data/crop_yields.csv',index=False)
    for field,i in [('Respondent gender',3),('Household type',13),('Ward',7)]:
        counts=df.iloc[:,i].fillna('Missing').value_counts().rename_axis('category').reset_index(name='records');counts.insert(0,'dimension',field)
        counts.to_csv(ROOT/'data'/f'{field.lower().replace(" ","_")}.csv',index=False)
    principle=[]
    answered=yes(179)
    for label,i in [('Crop rotation',181),('Minimum tillage',182),('Soil covering',183),('Intercropping',184)]:
        x=num(i);valid=answered&x.isin([0,1]);principle.append({'practice':label,'yes_records':int(x[valid].eq(1).sum()),'valid_responses':int(valid.sum()),'percent':100*x[valid].eq(1).mean()})
    pd.DataFrame(principle).to_csv(ROOT/'data/practices.csv',index=False)
    qa += [{'check':'Survey records','count':len(df)}, {'check':'Duplicate submission UUIDs beyond first occurrence','count':int(df.iloc[:,342].dropna().duplicated().sum())},{'check':'Invalid or missing inadequate-food month totals','count':int((~valid_food(df,177)).sum())},{'check':'Stored adequate-food total inconsistent with 12 minus inadequate months','count':int((num(178).notna()&num(177).notna()&(num(178)!=(12-num(177)))).sum())},{'check':'CA practice and CA principles yes/no answers differ','count':int((yes(18)!=yes(179)).sum())}]
    pd.DataFrame(qa).to_csv(ROOT/'data/quality_checks.csv',index=False)
    dates=pd.to_datetime(df.iloc[:,0],errors='coerce')
    (ROOT/'data/provenance.json').write_text(json.dumps({'source_name':Path(source).name,'records':len(df),'columns':len(df.columns),'survey_start':str(dates.min().date()),'survey_end':str(dates.max().date()),'published_data':'Aggregate tables only; no respondent records or identifiers','deduplication':'No records removed; duplicate UUIDs checked. Unique household status is not independently verified.'},indent=2))
def valid_food(df,i):
    x=pd.to_numeric(df.iloc[:,i],errors='coerce');return x.between(0,12)&(x%1==0)
if __name__=='__main__':main(sys.argv[1])
